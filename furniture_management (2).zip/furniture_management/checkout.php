<?php
session_start();
require "config.php";
require "whatsapp_helper.php";

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: shop.php");
    exit;
}

// Logged-in Customer details & ID-ஐ fetch செய்கிறோம்
$cust_id = NULL;
$c_name = "";
$c_phone = "";
$c_address = "";

if (isset($_SESSION['customer_id'])) {
    $cust_id = $_SESSION['customer_id'];
    $stmt_user = $conn->prepare("SELECT name, phone, address FROM customers WHERE id = ?");
    $stmt_user->bind_param("i", $cust_id);
    $stmt_user->execute();
    $res_user = $stmt_user->get_result();
    if ($row_user = $res_user->fetch_assoc()) {
        $c_name = $row_user['name'];
        $c_phone = $row_user['phone'];
        $c_address = $row_user['address'];
    }
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_name = trim($_POST['name']);
    $customer_phone = trim($_POST['phone']);
    $customer_address = trim($_POST['address']);
    
    // Calculate Total Amount
    $total_amount = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }

    $order_date = date("Y-m-d");
    $status = "Pending";

    // customer_id-ஐயும் சேர்த்து Orders Table-இல் Insert செய்கிறோம்
    $stmt = $conn->prepare("INSERT INTO orders (customer_id, customer_name, phone, address, order_date, status, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssd", $cust_id, $customer_name, $customer_phone, $customer_address, $order_date, $status, $total_amount);

    if ($stmt->execute()) {
        $order_id = $stmt->insert_id;

        // Insert Order Items
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            $stmt_item->bind_param("iiid", $order_id, $product_id, $item['quantity'], $item['price']);
            $stmt_item->execute();
        }

        // WhatsApp Notification to Admin
        sendAdminWhatsAppNotification($order_id, $customer_name, $customer_phone, $total_amount);

        // Clear Cart
        unset($_SESSION['cart']);
        
        echo "<script>alert('Order placed successfully!'); window.location.href='shop.php';</script>";
        exit;
    } else {
        $message = "Order placement failed. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f8fafc; padding: 40px; margin: 0; }
        .checkout-container { max-width: 500px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        h2 { margin-top: 0; color: #1e293b; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-size: 14px; margin-bottom: 5px; color: #475569; font-weight: 500; }
        input, textarea { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; box-sizing: border-box; }
        .btn-confirm { background: #d35400; color: #fff; border: none; width: 100%; padding: 12px; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 16px; margin-top: 10px; }
        .btn-confirm:hover { background: #b04300; }
    </style>
</head>
<body>

<div class="checkout-container">
    <h2>📋 Complete Your Order</h2>
    <?php if ($message): ?><p style="color: red;"><?= $message ?></p><?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($c_name) ?>" required placeholder="Enter your name">
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($c_phone) ?>" required placeholder="Enter WhatsApp phone number">
        </div>
        <div class="form-group">
            <label>Delivery Address</label>
            <textarea name="address" rows="3" required placeholder="Enter complete address"><?= htmlspecialchars($c_address) ?></textarea>
        </div>
        <button type="submit" class="btn-confirm">Confirm Order</button>
    </form>
</div>

</body>
</html>