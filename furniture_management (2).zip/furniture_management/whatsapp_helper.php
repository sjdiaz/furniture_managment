<?php
function sendAdminWhatsAppNotification($orderId, $customerName, $customerPhone, $totalAmount) {
    // UltraMsg Credentials
    $instanceId = "instance192260";
    $token      = "hnc4sfs4bjkedo74";
    
    // Admin Notification பெற வேண்டிய WhatsApp எண்
    $adminPhone = "+94776446513"; 

    $message  = "🚨 *NEW FURNITURE ORDER RECEIVED!* 🚨\n\n";
    $message .= "📦 *Order ID:* #" . $orderId . "\n";
    $message .= "👤 *Customer Name:* " . $customerName . "\n";
    $message .= "📞 *Customer Phone:* " . $customerPhone . "\n";
    $message .= "💰 *Total Amount:* Rs. " . number_format($totalAmount, 2) . "\n\n";
    $message .= "Please check Admin Dashboard for details.";

    $params = array(
        'token' => $token,
        'to'    => $adminPhone,
        'body'  => $message
    );

    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.ultramsg.com/" . $instanceId . "/messages/chat",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => http_build_query($params),
      CURLOPT_HTTPHEADER => array("content-type: application/x-www-form-urlencoded"),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
}
?>